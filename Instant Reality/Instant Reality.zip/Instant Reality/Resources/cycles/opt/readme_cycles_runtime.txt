Runtime files for Cycles path tracer, part of Blender.
Needed by CyclesNodePool.

Cycles itself is licensed under Apache 2.0 by the Blender Foundation.
http://www.blender.org/foundation/
http://www.apache.org/licenses/LICENSE-2.0.html

The Cycles C API is also Apache 2.0.

Some 3rd party software uses other licenses, see directory 'license' for details.
